import pprint

class Laud:
  
  def __init__(self, pikkus, laius):
    self.pikkus = pikkus
    self.laius = laius
    self.laud = {}
  
  def init_laud(self): #Laud alustab lugemist ülevalt vasakult
    for i in range(self.pikkus): #Laua kõrgus
      self.laud[i] = {}
      for j in range(self.laius): #Laua laius
        self.laud[i][j] = 0
# 0,0 0,1 0,2 ...
# 1,0 1,1 1,2 ...
# ...
  def print_laud(self):
    pp  = pprint.PrettyPrinter(indent=4)
    pp.pprint(self.laud)
    print()

# esimene laud (h nagu heatmap)
mangijah = Laud(10, 10) #Siin hoitakse mängija heatmapi
mangijah.init_laud()
mangijah.print_laud()

# teine laud (l nagu laev)
mangijal = Laud(10,10) #Siin hoitakse mängija laevade informatsiooni
mangijal.init_laud()
mangijal.print_laud()

# kolmas laud (l nagu laev)
arvutil = Laud(10,10) #Siin hoitakse arvuti laevade informatsiooni
arvutil.init_laud()
arvutil.print_laud()

# neljas laud (p nagu pomm)
arvutip = Laud(10,10) #Siin hoitakse arvuti pommitamise informatsiooni
arvutip.init_laud()
arvutip.print_laud()

# viies laud (p nagu pomm)
mangijap = Laud(10,10) #Siin hoitakse mängija pommitamise informatsiooni
mangijap.init_laud()
mangijap.print_laud()

#Raskustasemed